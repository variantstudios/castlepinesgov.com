# Drupal Custom Template Folder

Put any templates to override Aurora templates, Drupal Core templates, Drupal Contrib templates, or any custom templates in this folder.
