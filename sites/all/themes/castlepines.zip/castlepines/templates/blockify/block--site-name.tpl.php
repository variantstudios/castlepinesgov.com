<div class="site-name">
  <a href="/" title="<?php print $sitename; ?>" rel="home">
    <h1>
      <?php print $sitename; ?>
    </h1>
  </a>
</div>