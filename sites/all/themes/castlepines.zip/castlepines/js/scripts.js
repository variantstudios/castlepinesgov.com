 (function ($) {
	$(document).ready(function() {
	
/* -------------- I Want To script ---------- */
  $('ul.dropdown.second li').click(function (e) {
    var value = $(this).data('value');
    $('.button').attr('href', value);
    $('.button').addClass('on');
  });

  $('ul.dropdown.first li').click(function () {
    $('ul.dropdown.first li').not(this).removeClass('active');    
    $(this).toggleClass('active');
    var activeCategory = $('ul.dropdown.first li.active').attr('id');
        $('ul.dropdown.second li').not(activeCategory).removeClass('show');  
        $('ul.dropdown.second li#' + activeCategory).toggleClass('show');
  });
  
  
  $('ul.dropdown.second li').click(function () {
    $('ul.dropdown.second li').not(this).removeClass('active');    
    $(this).toggleClass('active'); 
   }); 

/* ---------- End I Want To script --------- */

var $menu = $("#menu").clone();
$menu.attr( "id", "mobile-menu" );
$menu.mmenu({
     "slidingSubmenus": false
  });
  
  $("#mobile-toggle").click(function() {
     $("#mobile-menu").trigger("open.mm");
  });
 


	if(Modernizr.mq('only all')) {
		$('html').addClass('mq');
	} else {
        $('html').addClass('no-mq');
    };

  
  });
})(jQuery);